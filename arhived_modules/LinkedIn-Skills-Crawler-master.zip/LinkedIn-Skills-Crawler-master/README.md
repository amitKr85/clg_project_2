# A Complete List of LinkedIn Skills
A simple Python script to crawl complete list of LinkedIn skills

* Supports Python 2
* Python 3 support soon

## How to use
Replace "EMAIL_ID" and "PASSWORD" field in the main.py file with your LinkedIn credentials and run it.

## Ready to use
The complete list can be downloaded from [here](https://github.com/varadchoudhari/LinkedIn-Skills-Crawler/blob/master/output/all_skills.txt)
