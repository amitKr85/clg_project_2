# keyword_extractor
Code extracts keywords from abstracts of research papers and state the technical skills required.
